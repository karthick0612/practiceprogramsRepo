package HackerRank;

public class sampleClass {
}
