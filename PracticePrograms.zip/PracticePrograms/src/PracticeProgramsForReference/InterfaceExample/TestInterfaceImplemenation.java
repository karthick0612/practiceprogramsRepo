package PracticeProgramsForReference.InterfaceExample;

public  class TestInterfaceImplemenation implements TestInterface,TestInterface1 {

    public void test1() {
        System.out.println("Rest Assured");
    }

    public void test2() {
        System.out.println("Web Services with Cucumber Framework");
    }


}
