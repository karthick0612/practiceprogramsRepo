package PracticeProgramsForReference.InterfaceExample;

public class Sample {


}
