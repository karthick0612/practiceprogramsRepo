package PracticeProgramsForReference.InterfaceExample;

public interface TestInterface1 {

    void test1();
    void test2();
}
