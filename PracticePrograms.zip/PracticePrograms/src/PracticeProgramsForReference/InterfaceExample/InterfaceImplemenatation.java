package PracticeProgramsForReference.InterfaceExample;

public class InterfaceImplemenatation {

    public static void main(String[] args){
        TestInterfaceImplemenation test = new TestInterfaceImplemenation();
        test.sampleTest2();
        test.test1();
        test.test2();

        TestInterface testInterface = new TestInterfaceImplemenation();
        testInterface.sampleTest2();
    }
}
