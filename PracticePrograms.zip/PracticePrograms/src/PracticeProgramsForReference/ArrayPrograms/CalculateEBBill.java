package PracticeProgramsForReference.ArrayPrograms;

public class CalculateEBBill {
    public static void main(String[] args){


    }
}
