package PracticeProgramsForReference;

public class ChildExample extends ParentExample {
    public void testMethod(String Value1, String value2){

        System.out.println(Value1+value2);
        System.out.println("Rest API Automation");
    }

    public void testMethod(){
        System.out.println("Karthick1");
    }
}
