package PracticeProgramsForReference;

public class ParentExample {

    public void testMethod(String Value1, String value2){

        System.out.println(Value1+value2);
        System.out.println("Automation");
    }

    public void testMethod(){
        System.out.println("Karthick23");
    }
}
