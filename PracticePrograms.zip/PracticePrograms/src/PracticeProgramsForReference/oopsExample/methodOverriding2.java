package PracticeProgramsForReference.oopsExample;

public class methodOverriding2 extends methodOverriding1{

    public void methodOverridingExample(){
        System.out.println("Karthick Automation Tester");
    }
}
