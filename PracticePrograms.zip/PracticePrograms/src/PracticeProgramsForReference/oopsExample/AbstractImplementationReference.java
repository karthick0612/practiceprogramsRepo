package PracticeProgramsForReference.oopsExample;

public class AbstractImplementationReference extends ExampleAbstract{
    @Override
    void sample() {
        System.out.println("Karthick");
    }
}
