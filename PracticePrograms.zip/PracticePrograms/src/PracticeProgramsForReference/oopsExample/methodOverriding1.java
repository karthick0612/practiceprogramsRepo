package PracticeProgramsForReference.oopsExample;

public class methodOverriding1 {

    public void methodOverridingExample(){
        System.out.println("JAVA Testing ");
    }
}
