package PracticeProgramsForReference;

public class StringIntroduction {
    private String str = "karthick";
    public String str1 = "string";

}
