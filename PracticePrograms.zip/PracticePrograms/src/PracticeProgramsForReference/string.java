package PracticeProgramsForReference;

public class string extends StringIntroduction{


    public static void main(String[] args){

    }

    public void test1(){
        System.out.println(str1);
    }
}
