package com.abc.projectpage;

import org.testng.annotations.Test;

public class sample {

	@Test
	public void sample1() {
		System.out.println("sample");
		
	}
}
