package com.abc.projectpage;

import org.testng.annotations.Test;

public class SampleJava {
    @Test
    public void sample(){
        System.out.println("TestNG Framework");
    }
}
