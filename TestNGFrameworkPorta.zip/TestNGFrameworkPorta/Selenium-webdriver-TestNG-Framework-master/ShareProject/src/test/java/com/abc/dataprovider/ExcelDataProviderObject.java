package com.abc.dataprovider;

import java.util.ArrayList;

public class ExcelDataProviderObject {

	public ArrayList<String> DataArray = new ArrayList<String>();
	
	public ExcelDataProviderObject( ArrayList<String> items)
	 {
		this.DataArray =items;
	    
	 }
	
	
	
}
